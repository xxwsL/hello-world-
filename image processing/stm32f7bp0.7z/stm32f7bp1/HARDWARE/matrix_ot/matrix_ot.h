#ifndef  _matrix_ot_h_
#define  _matrix_ot_h_
#include "xxwsL.h"

//�����ʼ����
#define MatrixMessage(Mateiname) (float*)Mateiname,sizeof(Mateiname)/sizeof(Mateiname[0]),(sizeof(Mateiname[0])/4)
#define MatrixFunction (output)
#define MatrixInit(Mateiname) {MatrixMessage(Mateiname),MatrixFunction}

typedef struct MatrixStruct{
	// ������Ϣ
	float*  SaveAddr;
	unsigned char Line;
	unsigned char Row;
	//������ú���
	int (*output) (struct MatrixStruct);

}MatStr;

int output(MatStr mat);
int transpose(MatStr mat);

#endif // ! _matrix_ot_h_
