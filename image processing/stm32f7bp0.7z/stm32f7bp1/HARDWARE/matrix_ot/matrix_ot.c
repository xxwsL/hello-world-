#include "matrix_ot.h"

int output(MatStr mat)							//�������
{
	unsigned char i, j;
	unsigned char iadd;
	unsigned char g[12];
	for (i = 0; i < mat.Line; i++)
	{
		iadd=i*(mat.Line-1);
		for (j = 0; j < mat.Row; j++)
		{
		    g[iadd+j]=*(mat.SaveAddr+iadd+j);
//			printf("%f\t", *(mat.SaveAddr ++));    //�Ʊ���ʽ�������
		} 
//		printf("\n");							   //\n
	}
	return true;
}

int transpose(MatStr mat)
{
	return true;
}


